#include "OS/semaphore.h"
#include <stdint.h>
#include "OS/os.h"

/**
 * @brief Non Static Initialisation of Semaphore
 * Allows for the initialisation of a semaphore with a given number of tokens
 * 
 * @param sem - Semaphore to be initialised
 * @param initial_tokens - Number of tokens to initialise the semaphore with
 */
void OS_semaphore_init(OS_semaphore_t *sem, uint32_t initial_tokens) {
	sem->tokens = initial_tokens;
	sem->initial_tokens = initial_tokens;
}

/**
 * @brief Obtain a token from the semaphore container
 * 
 * @param sem - Semaphore to obtain token from
 */
void OS_semaphore_obtain(OS_semaphore_t * const sem) {
	uint32_t notification_counter;
	uint32_t failure = 1;
	do {
		// Get latest notification count
		notification_counter = get_notification_counter();
		// Get current token count
		uint32_t current_token_count = (uint32_t) __LDREXW ((uint32_t *)&(sem->tokens));
		// No tokens available, clear exclusive lock and block.
		if (current_token_count == 0) {
			__CLREX();
			OS_wait(notification_counter);
		}
		// Decrement token count by one, as successfully obtained token
		failure = __STREXW ((current_token_count - 1), (uint32_t *)&(sem->tokens));
	} while(failure);
	OS_notifyAll();
}

/**
 * @brief Release a token from the semaphore container
 * 
 * @param sem - Semaphore to release token from
 */
void OS_semaphore_release(OS_semaphore_t * const sem) {
	uint32_t notification_counter;
	uint32_t failure = 1;
	do {
		// Get latest notification count
		notification_counter = get_notification_counter();
		// Get current token count
		uint32_t current_token_count = (uint32_t) __LDREXW ((uint32_t *)&(sem->tokens));
		if (current_token_count == sem->initial_tokens) {
			__CLREX();
			OS_wait(notification_counter);
		}
		// Increment token count by one, as successfully released token
		failure = __STREXW ((current_token_count + 1), (uint32_t *)&(sem->tokens));
	} while(failure);
	OS_notifyAll();
}